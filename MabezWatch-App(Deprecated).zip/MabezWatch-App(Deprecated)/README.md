# MabezWatch-App
A app to connect to a prototype "smart watch" using arduino and an OLED display

# Main features
  - Filter notifications from different app (Todo)
  - Holds notifications in a queue till the watch is ready for more notifications
  - One button connect
  - Low energy Gatt API
  
# Weather
  - Configure update times
  - Configure only get data over wifi (todo)
  
# Other functionality
 - Turn off bluetooth if watch goes out of range (todo)
 - Retry connect time out
